let navlink = document.querySelector(".navlink");

document.querySelector("#menuBtn").onclick = () => {
    navlink.classList.toggle('active');
}

// insert current year into footer
    try { document.getElementById('year').textContent = new Date().getFullYear(); } catch(e){}

// Contact form validation + success message
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('contactForm');
    if (!form) return;

    function showStatus(message, isError) {
        let status = form.querySelector('.form-status');
        if (!status) {
            status = document.createElement('div');
            status.className = 'form-status';
            form.prepend(status);
        }
        status.textContent = message;
        status.setAttribute('role', 'status');
        status.style.background = isError ? '#fff0f0' : '#f0fff4';
        status.style.color = isError ? '#8a0b0b' : '#0b5a2b';
        status.style.padding = '10px 12px';
        status.style.borderRadius = '8px';
        status.style.marginBottom = '12px';
        status.style.border = isError ? '1px solid #f5c2c2' : '1px solid #c6efda';
    }

    function clearStatus() {
        const status = form.querySelector('.form-status');
        if (status) status.remove();
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        clearStatus();
        const name = (form.querySelector('#name') || {}).value || '';
        const email = (form.querySelector('#email') || {}).value || '';
        const subject = (form.querySelector('#subject') || {}).value || '';
        const message = (form.querySelector('#message') || {}).value || '';

        if (!name.trim() || !email.trim() || !subject.trim() || !message.trim()) {
            showStatus('Please complete all required fields.', true);
            return;
        }

        const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRe.test(email.trim())) {
            showStatus('Please enter a valid email address.', true);
            return;
        }

        // If validation passes — show success message and reset form
        showStatus('Thank you for contacting us. we in touch shortly.', false);
        form.reset();
    });

    // Clear status when user edits fields
    ['#name', '#email', '#subject', '#message'].forEach(function (sel) {
        const el = form.querySelector(sel);
        if (el) el.addEventListener('input', clearStatus);
    });
});

// Carousel removed — no carousel JS required.

document.getElementById('year').textContent = new Date().getFullYear();

/* Legacy slider DOM-shuffle controls
   - Scoped to `.library-slider.legacy` so it doesn't affect other elements
   - Uses simple append/prepend to rotate `.item` elements when buttons clicked
*/
document.addEventListener('DOMContentLoaded', function () {
    const legacy = document.querySelector('.library-slider.legacy');
    if (!legacy) return; // no legacy slider on this page

    const slide = legacy.querySelector('.slide');
    const next = legacy.querySelector('.next');
    const prev = legacy.querySelector('.prev');

    if (!slide) return;

    function shiftNext() {
        const items = slide.querySelectorAll('.item');
        if (items.length === 0) return;
        // Move first item to the end
        slide.appendChild(items[0]);
    }

    function shiftPrev() {
        const items = slide.querySelectorAll('.item');
        if (items.length === 0) return;
        // Move last item to the start
        slide.prepend(items[items.length - 1]);
    }

    if (next) next.addEventListener('click', shiftNext);
    if (prev) prev.addEventListener('click', shiftPrev);
});

// Dark mode toggle: persist preference and toggle `dark-theme` on the html element
document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.getElementById('themeToggle');
    const root = document.documentElement;

    if (!toggle) return;

    function applyTheme(isDark) {
        if (isDark) {
            root.classList.add('dark-theme');
            toggle.setAttribute('aria-pressed', 'true');
            toggle.textContent = '☀️';
        } else {
            root.classList.remove('dark-theme');
            toggle.setAttribute('aria-pressed', 'false');
            toggle.textContent = '🌙';
        }
    }

    // Initialize from localStorage (or system preference)
    const stored = localStorage.getItem('theme');
    if (stored === 'dark') {
        applyTheme(true);
    } else if (stored === 'light') {
        applyTheme(false);
    } else {
        // fallback to prefers-color-scheme
        const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        applyTheme(prefersDark);
    }

    toggle.addEventListener('click', function () {
        const isDark = root.classList.toggle('dark-theme');
        applyTheme(isDark);
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });
});



